import { ContextDimension } from "@/types/customer-context";

export const contextDimensions: ContextDimension[] = [
  {
    id: "organizationalScope",
    title: "Organizational Scope & Complexity",
    options: [
      "Local",
      "Regional", 
      "Global",
      "Single ERP (SAP ECC)",
      "Single ERP (S/4HANA)",
      "Multiple ERP",
      "Single Entity",
      "Multi-Entity",
      "Joint Ventures",
      "Greenfield Rollout",
      "Phased Rollout",
      "Parallel Legacy Systems"
    ]
  },
  {
    id: "supplyChainComplexity",
    title: "Supply Chain & Procurement Complexity",
    options: [
      "Low complexity",
      "Medium complexity",
      "High complexity",
      "CAPEX sourcing",
      "OPEX sourcing",
      "MRO sourcing",
      "Project-based sourcing",
      "Simple procurement",
      "Engineer-to-Order",
      "Long-lead Equipment",
      "Integrated with Asset Management",
      "Non-integrated with Asset Management"
    ]
  },
  {
    id: "complianceRisk",
    title: "Compliance, Risk & Governance",
    options: [
      "Low regulatory environment",
      "Medium regulatory environment",
      "High regulatory environment",
      "Mandatory HSE compliance",
      "Optional HSE compliance",
      "Automated compliance enforcement",
      "Manual compliance enforcement",
      "Risk thresholds defined",
      "Risk thresholds not defined"
    ]
  },
  {
    id: "sustainability",
    title: "Sustainability & Strategic Sourcing Objectives",
    options: [
      "No sustainability programs",
      "Basic sustainability programs",
      "Advanced sustainability programs",
      "ESG criteria included",
      "ESG criteria not included",
      "No supplier collaboration",
      "Moderate supplier collaboration",
      "High supplier collaboration",
      "KPIs focused on Cost",
      "KPIs focused on Risk",
      "KPIs focused on Diversity",
      "KPIs focused on Sustainability"
    ]
  }
];