import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Building, ChevronRight } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import { CustomerContextData } from "@/types/customer-context";
import { contextDimensions } from "@/data/customer-context-data";

const CustomerContext = () => {
  const navigate = useNavigate();
  const { productId, moduleId } = useParams();
  
  const [contextData, setContextData] = useState<CustomerContextData>({
    organizationalScope: [],
    supplyChainComplexity: [],
    complianceRisk: [],
    sustainability: []
  });

  const moduleNames: { [key: string]: string } = {
    sourcing: "SAP Ariba Sourcing",
    contract: "SAP Ariba Contract Management",
    risk: "SAP Ariba Supplier Risk",
    lifecycle: "SAP Ariba Supplier Lifecycle and Performance",
    buying: "SAP Ariba Buying and Invoicing",
    guided: "SAP Ariba Guided Buying",
    invoice: "SAP Ariba Invoice Management"
  };

  const handleOptionToggle = (dimensionId: keyof CustomerContextData, option: string) => {
    setContextData(prev => {
      const currentOptions = prev[dimensionId];
      const isSelected = currentOptions.includes(option);
      
      return {
        ...prev,
        [dimensionId]: isSelected 
          ? currentOptions.filter(item => item !== option)
          : [...currentOptions, option]
      };
    });
  };

  const isFormComplete = () => {
    return Object.values(contextData).every(array => array.length > 0);
  };

  const handleContinue = () => {
    // Store context data for later use in BBP generation
    sessionStorage.setItem('customerContext', JSON.stringify(contextData));
    navigate(`/product/${productId}/module/${moduleId}/generation/bbp`);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-card shadow-sm border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center space-x-3">
            <Button 
              variant="ghost" 
              onClick={() => navigate(`/product/${productId}/module/${moduleId}`)} 
              className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <Building className="h-6 w-6 text-primary" />
            <div>
              <h1 className="text-2xl font-semibold text-foreground">
                Customer Context Capture
              </h1>
              <p className="text-muted-foreground">
                {moduleNames[moduleId || ''] || 'Unknown Module'} - Help us understand your business context
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8 text-center">
          <h2 className="text-2xl font-semibold text-foreground mb-3">
            Tell us about your business context
          </h2>
          <p className="text-muted-foreground text-lg">
            Select all options that apply to your organization. This information helps us provide more relevant recommendations.
          </p>
        </div>

        <div className="space-y-8">
          {contextDimensions.map((dimension, index) => (
            <Card key={dimension.id} className="bg-card border shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg text-foreground font-medium flex items-center gap-3">
                  <div className="bg-primary/10 text-primary rounded-full w-8 h-8 flex items-center justify-center text-sm font-semibold">
                    {index + 1}
                  </div>
                  {dimension.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {dimension.options.map((option, optionIndex) => (
                    <div key={optionIndex} className="flex items-center space-x-3 p-3 rounded-lg border border-border hover:bg-muted/50 transition-colors">
                      <Checkbox
                        id={`${dimension.id}-${optionIndex}`}
                        checked={contextData[dimension.id].includes(option)}
                        onCheckedChange={() => handleOptionToggle(dimension.id, option)}
                      />
                      <Label 
                        htmlFor={`${dimension.id}-${optionIndex}`} 
                        className="text-foreground cursor-pointer flex-1"
                      >
                        {option}
                      </Label>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 flex justify-center">
          <Button
            onClick={handleContinue}
            disabled={!isFormComplete()}
            className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-3 text-lg flex items-center gap-2"
          >
            Continue to BBP Generation
            <ChevronRight className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CustomerContext;