
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, FileText, Edit, Download, CheckCircle, Settings, Users, Database, MessageCircle, Send, Bot } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";

const BlueprintGeneration = () => {
  const navigate = useNavigate();
  const { productId, moduleId, templateId } = useParams();
  const [isGenerating, setIsGenerating] = useState(true);
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [chatInput, setChatInput] = useState("");
  const [isRegenerating, setIsRegenerating] = useState(false);
  const [chatMessages, setChatMessages] = useState<Array<{role: 'user' | 'assistant', content: string}>>([]);
  const [blueprintContent, setBlueprintContent] = useState({
    introduction: "This Business Blueprint Document (BBP) establishes the foundation for the SAP Ariba Sourcing solution at XYZ Company. It details the process transformation from the current manual procurement practices to a streamlined, digitally integrated sourcing environment, leveraging SAP Ariba Sourcing and its integration with SAP S/4HANA via Cloud Integration Gateway (CIG).",
    objective: "Define the future-state business process for Request for Quotation (RFQ) sourcing at XYZ Company using SAP Ariba Sourcing. Achieve end-to-end integration between SAP S/4HANA and Ariba through CIG with automated process flows. Enhance process transparency, compliance, and auditability.",
    asIsProcess: "Currently, the procurement process at XYZ Company follows these steps: Purchase Requisitions (PRs) are created manually in SAP S/4HANA. The procurement team negotiates with suppliers via email or telephone. Supplier quotations are collected and compared offline (Excel, email). Vendor selection is based on manual analysis. Purchase Orders (POs) are created manually in SAP S/4HANA post-negotiation and approval.",
    toBeProcess: "The future-state process leverages SAP Ariba Sourcing for fully automated, integrated, and auditable RFQ management. PR Creation: User creates a PR in SAP S/4HANA. Auto-RFQ Trigger: PR triggers automatic RFQ event creation in SAP Ariba via CIG. RFQ Setup: Single, standardized sourcing template used for all categories.",
    approvalMatrix: "Activity | Role | Approval Required | Comments\nRFQ Event Creation | Sourcing Manager | No | Initiates sourcing event\nPre-Publish Approval | Project Owner | Yes | Mandatory prior to event publication\nBid Evaluation | Sourcing Manager, Reviewer | No | Collaborative review; no workflow\nVendor Selection | Sourcing Manager | No | Based on auto comparative report",
    rolesResponsibilities: "Sourcing Manager: Role responsible for creating/managing sourcing events\nReviewer: Role responsible for reviewing bids and event activities\nProject Owner: Approver for RFQ event publishing\nEvent Owner: User who creates/owns the sourcing event",
    integrationArchitecture: "Integration Platform: SAP Cloud Integration Gateway (CIG). Integration Points: PRs from S/4HANA automatically trigger RFQ events in Ariba. Supplier and material masters are synchronized from S/4HANA to Ariba. Upon vendor selection in Ariba, POs are auto-created in S/4HANA.",
    masterData: "Supplier Master: Maintained in SAP S/4HANA as the system of record. Synced to SAP Ariba via CIG. No direct edits in Ariba; changes only via S/4HANA. Material Master: Maintained in SAP S/4HANA. Synced to SAP Ariba via CIG for sourcing events.",
    reporting: "Standard Reports: All standard SAP Ariba Sourcing reports are enabled (e.g., event status, supplier participation, bid history, award summary, audit logs). No custom reports or analytics dashboards. Audit: Complete audit trails are available in Ariba as standard."
  });

  const moduleNames: { [key: string]: string } = {
    sourcing: "SAP Ariba Sourcing",
    contract: "SAP Ariba Contract Management",
    risk: "SAP Ariba Supplier Risk",
    lifecycle: "SAP Ariba Supplier Lifecycle and Performance",
    buying: "SAP Ariba Buying and Invoicing",
    guided: "SAP Ariba Guided Buying",
    invoice: "SAP Ariba Invoice Management"
  };

  // Simulate generation process
  useState(() => {
    const timer = setTimeout(() => {
      setIsGenerating(false);
    }, 3000);
    return () => clearTimeout(timer);
  });

  const handleEdit = (section: string) => {
    setIsEditing(section);
  };

  const handleSave = (section: string, value: string) => {
    setBlueprintContent(prev => ({
      ...prev,
      [section]: value
    }));
    setIsEditing(null);
  };

  const handleExport = () => {
    // Simulate export functionality
    const element = document.createElement('a');
    const file = new Blob([JSON.stringify(blueprintContent, null, 2)], { type: 'application/json' });
    element.href = URL.createObjectURL(file);
    element.download = 'SAP_Ariba_Sourcing_Blueprint.json';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleChatSubmit = async () => {
    if (!chatInput.trim()) return;
    
    const userMessage = chatInput.trim();
    setChatMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setChatInput("");
    setIsRegenerating(true);

    // Simulate AI response with realistic content updates
    setTimeout(() => {
      const response = generateAIDummyResponse(userMessage, blueprintContent);
      setChatMessages(prev => [...prev, { 
        role: 'assistant', 
        content: response.message 
      }]);
      
      // Update blueprint content based on the dummy response
      if (response.updatedContent) {
        setBlueprintContent(prev => ({
          ...prev,
          ...response.updatedContent
        }));
      }
      
      setIsRegenerating(false);
    }, 2000 + Math.random() * 1000); // Random delay for realism
  };

  const generateAIDummyResponse = (userMessage: string, currentContent: any) => {
    const message = userMessage.toLowerCase();
    
    // Simulate different types of responses based on user input
    if (message.includes('approval') || message.includes('matrix')) {
      return {
        message: "I've updated the approval matrix to streamline the process. The changes include simplified approval levels and clearer role definitions.",
        updatedContent: {
          approvalMatrix: `Activity | Role | Approval Required | Comments
RFQ Event Creation | Sourcing Manager | No | Initiates sourcing event
Pre-Publish Approval | Project Owner | Yes | Mandatory prior to event publication - streamlined process
Bid Evaluation | Sourcing Manager, Reviewer | No | Collaborative review with enhanced guidelines
Vendor Selection | Sourcing Manager | No | Based on auto comparative report with simplified criteria
PO Approval (in S/4HANA) | As per S/4HANA DOA | As per S/4HANA | Expedited approval workflow`
        }
      };
    }
    
    if (message.includes('risk') || message.includes('management')) {
      return {
        message: "I've integrated risk management requirements into your blueprint. This includes supplier risk assessment and compliance checks.",
        updatedContent: {
          toBeProcess: currentContent.toBeProcess + "\n\n10. Risk Assessment: Automated supplier risk scoring during bid evaluation phase.\n11. Compliance Check: Mandatory compliance verification before vendor selection."
        }
      };
    }
    
    if (message.includes('reporting') || message.includes('analytics')) {
      return {
        message: "I've enhanced the reporting section with additional analytics capabilities and custom dashboards for better insights.",
        updatedContent: {
          reporting: `Standard Reports: All standard SAP Ariba Sourcing reports are enabled including event status, supplier participation, bid history, award summary, and audit logs.

Enhanced Analytics: 
• Real-time sourcing dashboard with KPI tracking
• Supplier performance metrics and scorecards  
• Cost savings analysis and reporting
• Cycle time optimization insights
• Compliance monitoring reports

Custom Reports: Configurable reports for executive summary, category analysis, and vendor comparison metrics.

Audit: Complete audit trails with enhanced search and filtering capabilities for improved compliance management.`
        }
      };
    }
    
    if (message.includes('integration') || message.includes('s/4hana')) {
      return {
        message: "I've updated the integration architecture to include enhanced error handling and monitoring capabilities.",
        updatedContent: {
          integrationArchitecture: `Integration Platform: SAP Cloud Integration Gateway (CIG) with enhanced monitoring.

Integration Points: 
• PRs from S/4HANA automatically trigger RFQ events in Ariba with real-time status updates
• Supplier and material masters are synchronized with bi-directional sync capabilities
• Upon vendor selection in Ariba, POs are auto-created in S/4HANA with confirmation workflow

Data Flow: 
• Outbound: PR, master data to Ariba with validation checkpoints
• Inbound: RFQ results, PO creation back to S/4HANA with error recovery

Error Handling: 
• Advanced SAP error monitoring with automated alerts
• Integration logging/traceability via CIG dashboard
• Automatic retry mechanisms for failed transactions
• Real-time notification system for integration issues`
        }
      };
    }
    
    if (message.includes('objective') || message.includes('goal')) {
      return {
        message: "I've refined the objectives to align better with your strategic goals and added measurable outcomes.",
        updatedContent: {
          objective: `The objective of this BBP is to:
• Define the future-state business process for Request for Quotation (RFQ) sourcing at XYZ Company using SAP Ariba Sourcing
• Achieve end-to-end integration between SAP S/4HANA and Ariba through CIG with automated process flows
• Enhance process transparency, compliance, and auditability with real-time visibility
• Minimize manual intervention and standardize sourcing practices across all procurement categories
• Reduce sourcing cycle time by 40% and increase process efficiency by 60%
• Improve supplier engagement and competition through streamlined digital processes
• Provide a blueprint for configuration, role governance, and reporting aligned to XYZ's business goals
• Enable data-driven decision making through comprehensive analytics and reporting`
        }
      };
    }
    
    // Default response for other queries
    return {
      message: `I've analyzed your request: "${userMessage}". I've made relevant updates to enhance your Business Blueprint with improved clarity and additional details. The changes are now reflected in the document above.`,
      updatedContent: null
    };
  };

  if (isGenerating) {
    return (
      <div className="min-h-screen bg-background">
        <div className="bg-card shadow-sm border-b border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex items-center space-x-3">
              <Button variant="ghost" onClick={() => navigate(`/product/${productId}/module/${moduleId}/generation/bbp/questionnaire/${templateId}`)} className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted">
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <FileText className="h-6 w-6 text-primary" />
              <div>
                <h1 className="text-2xl font-semibold text-foreground">
                  Generating Business Blueprint
                </h1>
                <p className="text-muted-foreground">Processing your requirements...</p>
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <Card className="bg-card border shadow-lg">
            <CardContent className="py-16 text-center">
              <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-primary mx-auto mb-6"></div>
              <h3 className="text-xl font-semibold text-foreground mb-2">Analyzing Your Requirements</h3>
              <p className="text-muted-foreground mb-6">Our AI is processing your questionnaire responses and generating a comprehensive Business Blueprint document...</p>
              <div className="space-y-2 text-sm text-muted-foreground">
                <p className="flex items-center justify-center gap-2">
                  <CheckCircle className="h-4 w-4 text-success" />
                  Processing questionnaire responses
                </p>
                <p className="flex items-center justify-center gap-2">
                  <CheckCircle className="h-4 w-4 text-success" />
                  Mapping business requirements
                </p>
                <p className="flex items-center justify-center gap-2 text-primary">
                  <div className="h-4 w-4 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                  Generating blueprint sections
                </p>
                <p className="flex items-center justify-center gap-2">
                  <div className="h-4 w-4 border-2 border-muted border-t-transparent rounded-full"></div>
                  Finalizing document structure
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-card shadow-sm border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button variant="ghost" onClick={() => navigate(`/product/${productId}/module/${moduleId}/generation/bbp/questionnaire/${templateId}`)} className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted">
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <FileText className="h-6 w-6 text-primary" />
              <div>
                <h1 className="text-2xl font-semibold text-foreground">
                  {moduleNames[moduleId || '']} - Business Blueprint
                </h1>
                <p className="text-muted-foreground">Review and edit your generated blueprint</p>
              </div>
            </div>
            <Button onClick={handleExport} className="bg-success hover:bg-success/90 text-success-foreground shadow-sm">
              <Download className="h-4 w-4 mr-2" />
              Export Blueprint
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Blueprint Content */}
        <div className="lg:col-span-2">
          <div className="mb-6">
            <Badge className="bg-success/10 text-success border-success/20 mb-4">
              <CheckCircle className="h-4 w-4 mr-1" />
              Blueprint Generated Successfully
            </Badge>
            <p className="text-muted-foreground">
              Your Business Blueprint has been generated. Use the chat assistant to make changes with natural language.
            </p>
          </div>

        <div className="space-y-6">
          {/* Introduction */}
          <Card className="bg-card border shadow-sm hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-foreground font-medium">1. Introduction</CardTitle>
                <Button variant="ghost" size="sm" onClick={() => handleEdit('introduction')} className="text-muted-foreground hover:text-foreground">
                  <Edit className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isEditing === 'introduction' ? (
                <div className="space-y-3">
                  <Textarea
                    value={blueprintContent.introduction}
                    onChange={(e) => setBlueprintContent(prev => ({...prev, introduction: e.target.value}))}
                    className="min-h-[100px] bg-muted/30 border-border text-foreground focus:ring-primary"
                  />
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => handleSave('introduction', blueprintContent.introduction)} className="bg-primary hover:bg-primary/90">
                      Save
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => setIsEditing(null)} className="border-border text-muted-foreground">
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="text-muted-foreground text-sm leading-relaxed">{blueprintContent.introduction}</p>
              )}
            </CardContent>
          </Card>

          {/* Objective */}
          <Card className="bg-card border shadow-sm hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-foreground font-medium">2. Objective</CardTitle>
                <Button variant="ghost" size="sm" onClick={() => handleEdit('objective')} className="text-muted-foreground hover:text-foreground">
                  <Edit className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isEditing === 'objective' ? (
                <div className="space-y-3">
                  <Textarea
                    value={blueprintContent.objective}
                    onChange={(e) => setBlueprintContent(prev => ({...prev, objective: e.target.value}))}
                    className="min-h-[100px] bg-muted/30 border-border text-foreground focus:ring-primary"
                  />
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => handleSave('objective', blueprintContent.objective)} className="bg-primary hover:bg-primary/90">
                      Save
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => setIsEditing(null)} className="border-border text-muted-foreground">
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="text-muted-foreground text-sm leading-relaxed">{blueprintContent.objective}</p>
              )}
            </CardContent>
          </Card>

          {/* As-Is Process */}
          <Card className="bg-card border shadow-sm hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-foreground font-medium">3. As-Is Process Description</CardTitle>
                <Button variant="ghost" size="sm" onClick={() => handleEdit('asIsProcess')} className="text-muted-foreground hover:text-foreground">
                  <Edit className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isEditing === 'asIsProcess' ? (
                <div className="space-y-3">
                  <Textarea
                    value={blueprintContent.asIsProcess}
                    onChange={(e) => setBlueprintContent(prev => ({...prev, asIsProcess: e.target.value}))}
                    className="min-h-[100px] bg-muted/30 border-border text-foreground focus:ring-primary"
                  />
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => handleSave('asIsProcess', blueprintContent.asIsProcess)} className="bg-primary hover:bg-primary/90">
                      Save
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => setIsEditing(null)} className="border-border text-muted-foreground">
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="text-muted-foreground text-sm leading-relaxed">{blueprintContent.asIsProcess}</p>
              )}
            </CardContent>
          </Card>

          {/* To-Be Process with Flowchart */}
          <Card className="bg-card border shadow-sm hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-foreground font-medium">4. To-Be Process Design</CardTitle>
                <Button variant="ghost" size="sm" onClick={() => handleEdit('toBeProcess')} className="text-muted-foreground hover:text-foreground">
                  <Edit className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {isEditing === 'toBeProcess' ? (
                <div className="space-y-3">
                  <Textarea
                    value={blueprintContent.toBeProcess}
                    onChange={(e) => setBlueprintContent(prev => ({...prev, toBeProcess: e.target.value}))}
                    className="min-h-[100px] bg-muted/30 border-border text-foreground focus:ring-primary"
                  />
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => handleSave('toBeProcess', blueprintContent.toBeProcess)} className="bg-primary hover:bg-primary/90">
                      Save
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => setIsEditing(null)} className="border-border text-muted-foreground">
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <>
                  <p className="text-muted-foreground text-sm leading-relaxed">{blueprintContent.toBeProcess}</p>
                  <div className="border border-border rounded-lg p-4 bg-muted/20">
                    <h4 className="text-foreground font-medium mb-4">Process Flow Diagram</h4>
                    <div className="mermaid-container text-center">
                      <svg viewBox="0 0 800 600" className="w-full h-auto max-w-4xl mx-auto">
                        {/* Simplified flowchart representation */}
                        <defs>
                          <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="10" refY="3.5" orient="auto">
                            <polygon points="0 0, 10 3.5, 0 7" fill="hsl(var(--primary))" />
                          </marker>
                        </defs>
                        
                        {/* Process boxes */}
                        <rect x="50" y="50" width="120" height="40" rx="5" fill="hsl(var(--muted))" stroke="hsl(var(--primary))" strokeWidth="2"/>
                        <text x="110" y="75" textAnchor="middle" fill="hsl(var(--foreground))" fontSize="12">PR in S/4HANA</text>
                        
                        <rect x="50" y="130" width="120" height="40" rx="5" fill="hsl(var(--muted))" stroke="hsl(var(--primary))" strokeWidth="2"/>
                        <text x="110" y="155" textAnchor="middle" fill="hsl(var(--foreground))" fontSize="12">Auto RFQ in Ariba</text>
                        
                        <rect x="250" y="130" width="120" height="40" rx="5" fill="hsl(var(--muted))" stroke="hsl(var(--primary))" strokeWidth="2"/>
                        <text x="310" y="155" textAnchor="middle" fill="hsl(var(--foreground))" fontSize="12">Pre-publish Approval</text>
                        
                        <rect x="450" y="130" width="120" height="40" rx="5" fill="hsl(var(--muted))" stroke="hsl(var(--primary))" strokeWidth="2"/>
                        <text x="510" y="155" textAnchor="middle" fill="hsl(var(--foreground))" fontSize="12">RFQ Published</text>
                        
                        <rect x="450" y="210" width="120" height="40" rx="5" fill="hsl(var(--muted))" stroke="hsl(var(--primary))" strokeWidth="2"/>
                        <text x="510" y="235" textAnchor="middle" fill="hsl(var(--foreground))" fontSize="12">Supplier Bids</text>
                        
                        <rect x="250" y="210" width="120" height="40" rx="5" fill="hsl(var(--muted))" stroke="hsl(var(--primary))" strokeWidth="2"/>
                        <text x="310" y="235" textAnchor="middle" fill="hsl(var(--foreground))" fontSize="12">Evaluation Phase</text>
                        
                        <rect x="50" y="210" width="120" height="40" rx="5" fill="hsl(var(--muted))" stroke="hsl(var(--primary))" strokeWidth="2"/>
                        <text x="110" y="235" textAnchor="middle" fill="hsl(var(--foreground))" fontSize="12">Vendor Selection</text>
                        
                        <rect x="50" y="290" width="120" height="40" rx="5" fill="hsl(var(--muted))" stroke="hsl(var(--primary))" strokeWidth="2"/>
                        <text x="110" y="315" textAnchor="middle" fill="hsl(var(--foreground))" fontSize="12">Auto PO Creation</text>
                        
                        {/* Arrows */}
                        <line x1="110" y1="90" x2="110" y2="130" stroke="hsl(var(--primary))" strokeWidth="2" markerEnd="url(#arrowhead)"/>
                        <line x1="170" y1="150" x2="250" y2="150" stroke="hsl(var(--primary))" strokeWidth="2" markerEnd="url(#arrowhead)"/>
                        <line x1="370" y1="150" x2="450" y2="150" stroke="hsl(var(--primary))" strokeWidth="2" markerEnd="url(#arrowhead)"/>
                        <line x1="510" y1="170" x2="510" y2="210" stroke="hsl(var(--primary))" strokeWidth="2" markerEnd="url(#arrowhead)"/>
                        <line x1="450" y1="230" x2="370" y2="230" stroke="hsl(var(--primary))" strokeWidth="2" markerEnd="url(#arrowhead)"/>
                        <line x1="250" y1="230" x2="170" y2="230" stroke="hsl(var(--primary))" strokeWidth="2" markerEnd="url(#arrowhead)"/>
                        <line x1="110" y1="250" x2="110" y2="290" stroke="hsl(var(--primary))" strokeWidth="2" markerEnd="url(#arrowhead)"/>
                      </svg>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {/* Approval Matrix */}
          <Card className="bg-card border shadow-sm hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-foreground font-medium flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  5. Approval Matrix
                </CardTitle>
                <Button variant="ghost" size="sm" onClick={() => handleEdit('approvalMatrix')} className="text-muted-foreground hover:text-foreground">
                  <Edit className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isEditing === 'approvalMatrix' ? (
                <div className="space-y-3">
                  <Textarea
                    value={blueprintContent.approvalMatrix}
                    onChange={(e) => setBlueprintContent(prev => ({...prev, approvalMatrix: e.target.value}))}
                    className="min-h-[100px] bg-muted/30 border-border text-foreground focus:ring-primary"
                  />
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => handleSave('approvalMatrix', blueprintContent.approvalMatrix)} className="bg-primary hover:bg-primary/90">
                      Save
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => setIsEditing(null)} className="border-border text-muted-foreground">
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <pre className="text-muted-foreground text-sm whitespace-pre-wrap">{blueprintContent.approvalMatrix}</pre>
              )}
            </CardContent>
          </Card>

          {/* Roles & Responsibilities */}
          <Card className="bg-card border shadow-sm hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-foreground font-medium">6. Roles & Responsibilities</CardTitle>
                <Button variant="ghost" size="sm" onClick={() => handleEdit('rolesResponsibilities')} className="text-muted-foreground hover:text-foreground">
                  <Edit className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isEditing === 'rolesResponsibilities' ? (
                <div className="space-y-3">
                  <Textarea
                    value={blueprintContent.rolesResponsibilities}
                    onChange={(e) => setBlueprintContent(prev => ({...prev, rolesResponsibilities: e.target.value}))}
                    className="min-h-[100px] bg-muted/30 border-border text-foreground focus:ring-primary"
                  />
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => handleSave('rolesResponsibilities', blueprintContent.rolesResponsibilities)} className="bg-primary hover:bg-primary/90">
                      Save
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => setIsEditing(null)} className="border-border text-muted-foreground">
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <pre className="text-muted-foreground text-sm whitespace-pre-wrap">{blueprintContent.rolesResponsibilities}</pre>
              )}
            </CardContent>
          </Card>

          {/* Integration Architecture */}
          <Card className="bg-card border shadow-sm hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-foreground font-medium flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  7. Integration with S/4HANA
                </CardTitle>
                <Button variant="ghost" size="sm" onClick={() => handleEdit('integrationArchitecture')} className="text-muted-foreground hover:text-foreground">
                  <Edit className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isEditing === 'integrationArchitecture' ? (
                <div className="space-y-3">
                  <Textarea
                    value={blueprintContent.integrationArchitecture}
                    onChange={(e) => setBlueprintContent(prev => ({...prev, integrationArchitecture: e.target.value}))}
                    className="min-h-[100px] bg-muted/30 border-border text-foreground focus:ring-primary"
                  />
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => handleSave('integrationArchitecture', blueprintContent.integrationArchitecture)} className="bg-primary hover:bg-primary/90">
                      Save
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => setIsEditing(null)} className="border-border text-muted-foreground">
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="text-muted-foreground text-sm leading-relaxed">{blueprintContent.integrationArchitecture}</p>
              )}
            </CardContent>
          </Card>

          {/* Master Data */}
          <Card className="bg-card border shadow-sm hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-foreground font-medium flex items-center gap-2">
                  <Database className="h-5 w-5" />
                  8. Master Data
                </CardTitle>
                <Button variant="ghost" size="sm" onClick={() => handleEdit('masterData')} className="text-muted-foreground hover:text-foreground">
                  <Edit className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isEditing === 'masterData' ? (
                <div className="space-y-3">
                  <Textarea
                    value={blueprintContent.masterData}
                    onChange={(e) => setBlueprintContent(prev => ({...prev, masterData: e.target.value}))}
                    className="min-h-[100px] bg-muted/30 border-border text-foreground focus:ring-primary"
                  />
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => handleSave('masterData', blueprintContent.masterData)} className="bg-primary hover:bg-primary/90">
                      Save
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => setIsEditing(null)} className="border-border text-muted-foreground">
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="text-muted-foreground text-sm leading-relaxed">{blueprintContent.masterData}</p>
              )}
            </CardContent>
          </Card>

          {/* Reporting & Analytics */}
          <Card className="bg-card border shadow-sm hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-foreground font-medium">9. Reporting & Analytics</CardTitle>
                <Button variant="ghost" size="sm" onClick={() => handleEdit('reporting')} className="text-muted-foreground hover:text-foreground">
                  <Edit className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isEditing === 'reporting' ? (
                <div className="space-y-3">
                  <Textarea
                    value={blueprintContent.reporting}
                    onChange={(e) => setBlueprintContent(prev => ({...prev, reporting: e.target.value}))}
                    className="min-h-[100px] bg-muted/30 border-border text-foreground focus:ring-primary"
                  />
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => handleSave('reporting', blueprintContent.reporting)} className="bg-primary hover:bg-primary/90">
                      Save
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => setIsEditing(null)} className="border-border text-muted-foreground">
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="text-muted-foreground text-sm leading-relaxed">{blueprintContent.reporting}</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* AI Chat Assistant */}
      <div className="lg:col-span-1">
        <Card className="bg-card border shadow-lg h-fit sticky top-6">
          <CardHeader className="border-b border-border">
            <CardTitle className="text-lg text-foreground flex items-center gap-2 font-medium">
              <Bot className="h-5 w-5 text-primary" />
              AI Assistant
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              Make changes to your blueprint using natural language
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 p-6">
            {/* Chat Messages */}
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {chatMessages.length === 0 ? (
                <div className="text-center text-muted-foreground py-8">
                  <MessageCircle className="h-8 w-8 mx-auto mb-3 opacity-50" />
                  <p className="text-sm font-medium mb-1">Start a conversation</p>
                  <p className="text-xs">Example: "Change the approval matrix to include finance approval"</p>
                </div>
              ) : (
                chatMessages.map((message, index) => (
                  <div key={index} className={`p-3 rounded-lg ${message.role === 'user' ? 'bg-primary/10 ml-4 border border-primary/20' : 'bg-muted mr-4'}`}>
                    <div className="flex items-start gap-2">
                      {message.role === 'assistant' && <Bot className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />}
                      <p className="text-sm text-foreground leading-relaxed">{message.content}</p>
                    </div>
                  </div>
                ))
              )}
              {isRegenerating && (
                <div className="p-3 rounded-lg bg-muted mr-4">
                  <div className="flex items-center gap-2">
                    <Bot className="h-4 w-4 text-primary" />
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Chat Input */}
            <div className="flex gap-2">
              <Input
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Describe the changes you want..."
                className="bg-muted/30 border-border text-foreground placeholder:text-muted-foreground focus:ring-primary"
                onKeyPress={(e) => e.key === 'Enter' && handleChatSubmit()}
                disabled={isRegenerating}
              />
              <Button 
                onClick={handleChatSubmit}
                disabled={!chatInput.trim() || isRegenerating}
                size="sm"
                className="bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>

            <div className="border-t border-border pt-4">
              <h4 className="text-sm font-medium text-foreground mb-3">Quick Actions</h4>
              <div className="space-y-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full text-left justify-start border-border text-muted-foreground hover:bg-muted hover:text-foreground"
                  onClick={() => setChatInput("Simplify the approval matrix to have only 2 levels")}
                >
                  Simplify approval matrix
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full text-left justify-start border-border text-muted-foreground hover:bg-muted hover:text-foreground"
                  onClick={() => setChatInput("Add risk management requirements to the process")}
                >
                  Add risk management
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full text-left justify-start border-border text-muted-foreground hover:bg-muted hover:text-foreground"
                  onClick={() => setChatInput("Update the process flow to include supplier qualification")}
                >
                  Include supplier qualification
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>

      </div>
    </div>
  );
};

export default BlueprintGeneration;
